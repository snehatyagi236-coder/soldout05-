function buyNow(product, price){
  document.getElementById('orderSummary').textContent =
    product + ' — ₹' + price;
  document.getElementById('payment').hidden = false;
  document.getElementById('payment').scrollIntoView({behavior:'smooth'});
}
function confirmOrder(){
  const email = 'snehatyagi236@gmail.com';
  const phone = '9286497081';
  alert('Thank you! Your payment confirmation has been received. We will contact you at ' + phone + ' / ' + email + '.');
}
